<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<title>MaxproLive</title>
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSrUeMhiLdtIjnk41BCHTiwhh6Xb2WcjIb6DUTWQ7-g5DbMT1UNkGvNKcggFlodI9bU94U&usqp=CAU">
<meta name="robots" content="noindex">
          <style>   *{

        font-family: 'Ubuntu', sans-serif;
         }
 .box1 {

         display: inline-block;
         border:2px solid black;
         text-align:center;
         align-items:center;
         margin:10px;
         background-color:#FDEBD0;
         border-radius:1.5rem;
         text-align:center;
         margin-left:-.7rem;
         margin-right:.8rem;

         }
         
         .container {Width:100%;
margin-left:.6rem;}

         
         .box1:hover{
             background-color: #92DCA1;
			 border-color:white;
			 border:4px solid white;
         }
         body {
                       text-align:center;
         align-items:center;
         background-image:url("https://images.hdqwalls.com/download/abstract-simple-background-4k-lp-1366x768.jpg");
         }

         .box1 a {

         text-decoration: none;
         color: black;
         line-height:10px ;
         background-color:red;
         }

         input:focus{

         transition: cubic-bezier(0.075, 0.82, 0.165, 1);
                    border-color:red;
         }

         h1 {

         font-family:: Georgia, 'Times New Roman', Times, serif;
         }

         #brand{

         text-decoration:none;
         color: white;
         }

         select{
             text-align: center;
         width:40%;
         height:38px;
         border: 1.5px solid yellow;
            border-radius:1rem;margin-left:-1.2rem;
         }

         option{
                 line-height:35px ;
                 border: 1px solid black;
                 border-radius:1.5rem;
                 font-size:18px;

         }

           input{

         width:40%;
         height:38px;
         border: 1.5px solid yellow;
         text-align: center;
            border-radius:1rem;
            font-size:18px;
            margin-left:-.4rem;
         }
         }

         .con   {

           display:flexbox;
           width:100%;
           margin:15px;
         margin:10px;
         text-align: center;


         }

         .dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  width:100%;
  border-radius:1rem;
  background-color:orangered;
  font-size: 16px;
  border: none;
  cursor: pointer;

}

.dropdown {
  position: relative;
  display: inline-block;
  width: :80% ;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100%;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}


         @media only screen and (max-width: 768px) {
 select, input, .drpbtn , .dropdown{
    width:85%;
  }

  .
}

</style>
<script src="https://cdn.jsdelivr.net/npm/lazysizes@5.3.2/lazysizes.min.js"></script>
</head>
<body>

<div id="jtvh1">
<a id="brand" href="#">
<h1>Maxpro Live [ SONY ]</h1>
</a>
</div>
<br>
                 
		<br><br><div class="con" >
    <div class="dropdown">
  <button class="dropbtn">Select Plateform</button>
  <div class="dropdown-content">

<a href="./index.php">JIO TV</a>
<a href="./zee5.php"> ZEE5</a>
  <a href="./sony.php">SONY LIV</a>

  </div>
</div> <br> <br>

 <form>
     <input id="search" type="search" placeholder="Search"/>
 </form>
</div>
<div id="content">
<div class="container">

<div class="box1">
<a href="play.php?c=Sony_SAB" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_SAB.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony SAB</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_HD" class="card">
<img class=" lazyloaded" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_HD.png" style="height: 120px" src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_HD.png">
<div class="card-body">
<p class="card-text">Sony HD</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_SAB_HD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_SAB_HD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony SAB HD</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_Pal" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Pal.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Pal</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Pix_HD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Pix_HD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Pix HD</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_Max_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/SET_MAX.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Max SD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Max_HD" class="card">
<img class=" lazyloaded" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Max_HD.png" style="height: 120px" src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Max_HD.png">
<div class="card-body">
<p class="card-text">Sony Max HD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_MAX2" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_MAX2.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony MAX2</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Six_HD" class="card">
<img class=" lazyloaded" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Six_HD.png" style="height: 120px" src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Six_HD.png">
<div class="card-body">
<p class="card-text">Sony Six HD</p>
</div>
</a>
</div><div class="box1">
<a href="play.php?c=Sony_Wah" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Wah.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Wah</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_SD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony SD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Pix_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Pix_SD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Pix SD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten_HD" class="card">
<img class=" lazyloaded" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten_HD.png" style="height: 120px" src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten_HD.png">
<div class="card-body">
<p class="card-text">Ten 1 HD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten2_HD" class="card">
<img class=" lazyloaded" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten2_HD.png" style="height: 120px" src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten2_HD.png">
<div class="card-body">
<p class="card-text">Ten 2 HD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten3_HD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten3_HD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Ten 3 HD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten_1" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten_1.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Ten 1</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten_2" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten_2.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Ten 2</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Ten_3" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Ten_3.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Ten 3</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_BBC_Earth_HD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_BBC_Earth_HD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony BBC Earth HD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Six_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Six_SD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Six SD</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_Yay_Hindi" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Yay_Hindi.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Yay Hindi</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_BBC_Earth_HD_Telugu" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_BBC_Earth_HD_Telugu.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony BBC Earth HD Telugu</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_BBC_Earth_HD_Tamil" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_BBC_Earth_HD_Tamil.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony BBC Earth HD Tamil</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_Marathi_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Marathi_SD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Marathi SD</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_aath" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_aath.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony aath</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_BBC_Earth_SD" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_BBC_Earth_SD.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony BBC Earth SD</p>
</div>
</a>
</div>

<div class="box1">
<a href="play.php?c=Sony_BBC_Earth_HD_English" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_BBC_Earth_HD_English.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony BBC Earth HD English</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Yay_Telugu" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Yay_Telugu.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Yay Telugu</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Yay_Telugu" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Yay_Telugu.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Yay Telugu</p>
</div>
</a>
</div>
<div class="box1">
<a href="play.php?c=Sony_Yay_Tamil" class="card">
<img class="lazyload" data-src="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Yay_Tamil.png" style="height: 120px">
<div class="card-body">
<p class="card-text">Sony Yay Tamil</p>
</div>
</a>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
              <script>
$(document).ready(function(){
  $("input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".box1").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

</body></html>